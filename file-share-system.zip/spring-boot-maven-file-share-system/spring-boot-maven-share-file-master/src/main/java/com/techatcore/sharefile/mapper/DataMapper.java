package com.techatcore.sharefile.mapper;

/*
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

// Unable to use it because it won't allow generic types
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface DataMapper<S, T> {
    T mapDomainToDto(S source);

    S mapDtoToDomain(T target);
}*/
