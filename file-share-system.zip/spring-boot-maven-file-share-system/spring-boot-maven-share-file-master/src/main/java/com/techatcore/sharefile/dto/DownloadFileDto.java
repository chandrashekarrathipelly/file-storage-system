package com.techatcore.sharefile.dto;

import lombok.Data;

@Data
public class DownloadFileDto {
    private String id;
    private String file;
}
