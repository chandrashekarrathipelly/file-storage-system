package com.techatcore.sharefile.utils;

public class Constants {
    public static final String ADMIN = "admin";
    public static final String USER = "user";
    public static final String PASSWORD = "test";
}
