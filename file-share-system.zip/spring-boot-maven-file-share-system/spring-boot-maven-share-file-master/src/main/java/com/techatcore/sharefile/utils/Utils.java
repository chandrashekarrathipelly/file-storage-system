package com.techatcore.sharefile.utils;

public class Utils {

    public static long getCurrentTime() {
        return System.currentTimeMillis();
    }
}
