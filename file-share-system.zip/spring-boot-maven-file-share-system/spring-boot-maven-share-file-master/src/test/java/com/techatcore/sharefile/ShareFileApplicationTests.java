package com.techatcore.sharefile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShareFileApplicationTests {


	@Test
	void contextLoads() {
	}


}
